import math

class CalculateExpectedScore:
    def __init__(self, rating_home, rating_away, won):
        self.rating_home = rating_home
        self.rating_away = rating_away
        self.won = won

    
